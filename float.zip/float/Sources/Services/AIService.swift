import Foundation
import Combine

enum AIServiceError: LocalizedError {
    case invalidConfiguration
    case networkError(Error)
    case invalidResponse
    case apiError(String)
    
    var errorDescription: String? {
        switch self {
        case .invalidConfiguration:
            return "Invalid API configuration. Please check your settings."
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        case .invalidResponse:
            return "Invalid response from API."
        case .apiError(let message):
            return "API error: \(message)"
        }
    }
}

protocol AIServiceProtocol {
    func sendMessage(_ messages: [ChatMessage], config: AIConfiguration) async throws -> String
}

class AIService: AIServiceProtocol {
    static let shared = AIService()
    
    private init() {}
    
    func sendMessage(_ messages: [ChatMessage], config: AIConfiguration) async throws -> String {
        guard !config.apiKey.isEmpty else {
            throw AIServiceError.invalidConfiguration
        }
        
        switch config.provider {
        case .openai:
            return try await sendOpenAIMessage(messages, config: config)
        case .anthropic:
            return try await sendAnthropicMessage(messages, config: config)
        case .custom:
            return try await sendCustomMessage(messages, config: config)
        }
    }
    
    private func sendOpenAIMessage(_ messages: [ChatMessage], config: AIConfiguration) async throws -> String {
        let endpoint = config.customEndpoint.isEmpty ? config.provider.endpoint : config.customEndpoint
        guard let url = URL(string: endpoint) else {
            throw AIServiceError.invalidConfiguration
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(config.apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let openAIMessages = messages.filter { $0.role != .system }.map { msg -> [String: Any] in
            return ["role": msg.role.rawValue, "content": msg.content]
        }
        
        let body: [String: Any] = [
            "model": config.model.isEmpty ? "gpt-4o" : config.model,
            "messages": openAIMessages,
            "stream": false
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw AIServiceError.invalidResponse
        }
        
        guard httpResponse.statusCode == 200 else {
            var errorMsg = "HTTP \(httpResponse.statusCode)"
            if let errorJson = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                if let error = errorJson["error"] as? [String: Any],
                   let message = error["message"] as? String {
                    errorMsg = message
                } else if let error = errorJson["error"] as? String {
                    errorMsg = error
                }
            }
            throw AIServiceError.apiError(errorMsg)
        }
        
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let choices = json["choices"] as? [[String: Any]],
              let firstChoice = choices.first,
              let message = firstChoice["message"] as? [String: Any],
              let content = message["content"] as? String else {
            throw AIServiceError.invalidResponse
        }
        
        return content
    }
    
    private func sendAnthropicMessage(_ messages: [ChatMessage], config: AIConfiguration) async throws -> String {
        guard let url = URL(string: config.provider.endpoint) else {
            throw AIServiceError.invalidConfiguration
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue(config.apiKey, forHTTPHeaderField: "x-api-key")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let systemMessage = messages.first { $0.role == .system }?.content ?? ""
        let nonSystemMessages = messages.filter { $0.role != .system }
        
        let anthropicMessages = nonSystemMessages.map { msg -> [String: Any] in
            return ["role": msg.role.rawValue, "content": msg.content]
        }
        
        var body: [String: Any] = [
            "model": config.model,
            "max_tokens": 4096,
            "messages": anthropicMessages
        ]
        
        if !systemMessage.isEmpty {
            body["system"] = systemMessage
        }
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw AIServiceError.invalidResponse
        }
        
        guard httpResponse.statusCode == 200 else {
            if let errorJson = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let error = errorJson["error"] as? [String: Any],
               let message = error["message"] as? String {
                throw AIServiceError.apiError(message)
            }
            throw AIServiceError.apiError("HTTP \(httpResponse.statusCode)")
        }
        
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let content = json["content"] as? [[String: Any]],
              let firstContent = content.first,
              let text = firstContent["text"] as? String else {
            throw AIServiceError.invalidResponse
        }
        
        return text
    }
    
    private func sendCustomMessage(_ messages: [ChatMessage], config: AIConfiguration) async throws -> String {
        guard !config.customEndpoint.isEmpty else {
            throw AIServiceError.invalidConfiguration
        }
        
        guard let url = URL(string: config.customEndpoint) else {
            throw AIServiceError.invalidConfiguration
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("\(config.provider.headerPrefix)\(config.apiKey)", forHTTPHeaderField: config.provider.headerKey)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let openAIMessages = messages.map { msg -> [String: Any] in
            return ["role": msg.role.rawValue, "content": msg.content]
        }
        
        let body: [String: Any] = [
            "model": config.model,
            "messages": openAIMessages,
            "stream": false
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw AIServiceError.invalidResponse
        }
        
        guard httpResponse.statusCode == 200 else {
            throw AIServiceError.apiError("HTTP \(httpResponse.statusCode)")
        }
        
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let choices = json["choices"] as? [[String: Any]],
              let firstChoice = choices.first,
              let message = firstChoice["message"] as? [String: Any],
              let content = message["content"] as? String else {
            throw AIServiceError.invalidResponse
        }
        
        return content
    }
}