import SwiftUI
import AppKit

@main
struct FloatAIApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}

struct MainView: View {
    var body: some View {
        Text("FloatAI is running")
            .padding()
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {
    static var shared: AppDelegate?
    var floatingWindowController: FloatingWindowController?
    var statusItem: NSStatusItem?
    var settingsWindow: NSWindow?
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        AppDelegate.shared = self
        setupStatusItem()
        setupFloatingWindow()
        setupGlobalHotkey()
    }
    
    func setupStatusItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        
        if let button = statusItem?.button {
            button.image = NSImage(systemSymbolName: "brain.head.profile", accessibilityDescription: "FloatAI")
        }
        
        let menu = NSMenu()
        menu.addItem(NSMenuItem(title: "Show FloatAI", action: #selector(showFloatingWindow), keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: "Settings...", action: #selector(openSettings), keyEquivalent: ","))
        menu.addItem(NSMenuItem.separator())
        menu.addItem(NSMenuItem(title: "Quit FloatAI", action: #selector(quitApp), keyEquivalent: "q"))
        statusItem?.menu = menu
    }
    
    func setupFloatingWindow() {
        floatingWindowController = FloatingWindowController()
        floatingWindowController?.showWindow(nil)
    }
    
    func setupGlobalHotkey() {
        NSEvent.addGlobalMonitorForEvents(matching: .keyDown) { [weak self] event in
            if event.modifierFlags.contains([.command, .shift]) && event.keyCode == 49 {
                self?.toggleFloatingWindow()
            }
        }
    }
    
    @objc func toggleFloatingWindow() {
        floatingWindowController?.toggleExpanded()
    }
    
    @objc func showFloatingWindow() {
        floatingWindowController?.showWindow(nil)
    }
    
    @objc func openSettings() {
        openSettingsWindow()
    }
    
    func openSettingsWindow() {
        if settingsWindow == nil {
            let settingsView = SettingsView()
            let hostingController = NSHostingController(rootView: settingsView)
            
            let window = NSWindow(contentViewController: hostingController)
            window.title = "FloatAI Settings"
            window.styleMask = [.titled, .closable]
            window.setContentSize(NSSize(width: 480, height: 380))
            window.center()
            settingsWindow = window
        }
        settingsWindow?.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }
    
    @objc func quitApp() {
        NSApplication.shared.terminate(nil)
    }
}