import SwiftUI

struct SettingsView: View {
    var body: some View {
        TabView {
            OpenAISettingsView()
                .tabItem {
                    Label("OpenAI", systemImage: "plus.circle")
                }
            
            AnthropicSettingsView()
                .tabItem {
                    Label("Anthropic", systemImage: "ant.circle")
                }
            
            CustomSettingsView()
                .tabItem {
                    Label("Custom", systemImage: "server.rack")
                }
        }
        .frame(width: 480, height: 380)
    }
}

struct OpenAISettingsView: View {
    @State private var apiKey: String = ""
    @State private var model: String = "gpt-4o"
    @State private var saved: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("OpenAI Configuration")
                .font(.headline)
                .padding(.top, 8)
            
            VStack(alignment: .leading, spacing: 8) {
                Text("API Key")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                SecureField("sk-...", text: $apiKey)
                    .textFieldStyle(.roundedBorder)
                    .onAppear {
                        let config = ConfigurationManager.shared.getConfiguration(for: .openai)
                        apiKey = config.apiKey
                        model = config.model.isEmpty ? "gpt-4o" : config.model
                    }
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Model")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Picker("Model", selection: $model) {
                    Text("GPT-4o").tag("gpt-4o")
                    Text("GPT-4 Turbo").tag("gpt-4-turbo")
                    Text("GPT-4").tag("gpt-4")
                    Text("GPT-3.5 Turbo").tag("gpt-3.5-turbo")
                }
                .labelsHidden()
            }
            
            Spacer()
            
            HStack {
                Button("Save") {
                    let config = AIConfiguration(provider: .openai, apiKey: apiKey, model: model, customEndpoint: "")
                    ConfigurationManager.shared.saveConfiguration(for: .openai, config: config)
                    saved = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { saved = false }
                }
                .disabled(apiKey.isEmpty)
                
                if saved {
                    Text("Saved!").foregroundColor(.green).font(.caption)
                }
                
                Spacer()
                
                Link("Get API Key →", destination: URL(string: "https://platform.openai.com/api-keys")!)
                    .font(.caption)
            }
        }
        .padding(20)
    }
}

struct AnthropicSettingsView: View {
    @State private var apiKey: String = ""
    @State private var model: String = "claude-3-5-sonnet-20241022"
    @State private var saved: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Anthropic Configuration")
                .font(.headline)
                .padding(.top, 8)
            
            VStack(alignment: .leading, spacing: 8) {
                Text("API Key")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                SecureField("sk-ant-...", text: $apiKey)
                    .textFieldStyle(.roundedBorder)
                    .onAppear {
                        let config = ConfigurationManager.shared.getConfiguration(for: .anthropic)
                        apiKey = config.apiKey
                        model = config.model.isEmpty ? "claude-3-5-sonnet-20241022" : config.model
                    }
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Model")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Picker("Model", selection: $model) {
                    Text("Claude 3.5 Sonnet").tag("claude-3-5-sonnet-20241022")
                    Text("Claude 3 Opus").tag("claude-3-opus-20240229")
                    Text("Claude 3 Sonnet").tag("claude-3-sonnet-20240229")
                    Text("Claude 3 Haiku").tag("claude-3-haiku-20240307")
                }
                .labelsHidden()
            }
            
            Spacer()
            
            HStack {
                Button("Save") {
                    let config = AIConfiguration(provider: .anthropic, apiKey: apiKey, model: model, customEndpoint: "")
                    ConfigurationManager.shared.saveConfiguration(for: .anthropic, config: config)
                    saved = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { saved = false }
                }
                .disabled(apiKey.isEmpty)
                
                if saved {
                    Text("Saved!").foregroundColor(.green).font(.caption)
                }
                
                Spacer()
                
                Link("Get API Key →", destination: URL(string: "https://console.anthropic.com/")!)
                    .font(.caption)
            }
        }
        .padding(20)
    }
}

struct CustomSettingsView: View {
    @State private var apiKey: String = ""
    @State private var endpoint: String = "http://localhost:11434/v1/chat/completions"
    @State private var model: String = "llama3"
    @State private var saved: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Custom API Configuration")
                .font(.headline)
                .padding(.top, 8)
            
            VStack(alignment: .leading, spacing: 8) {
                Text("API Key")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                SecureField("API Key", text: $apiKey)
                    .textFieldStyle(.roundedBorder)
                    .onAppear {
                        let config = ConfigurationManager.shared.getConfiguration(for: .custom)
                        apiKey = config.apiKey
                        endpoint = config.customEndpoint.isEmpty ? "http://localhost:11434/v1/chat/completions" : config.customEndpoint
                        model = config.model.isEmpty ? "llama3" : config.model
                    }
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Endpoint URL")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                TextField("http://localhost:11434/v1/chat/completions", text: $endpoint)
                    .textFieldStyle(.roundedBorder)
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Model Name")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                TextField("llama3", text: $model)
                    .textFieldStyle(.roundedBorder)
            }
            
            Spacer()
            
            HStack {
                Button("Save") {
                    let config = AIConfiguration(provider: .custom, apiKey: apiKey, model: model, customEndpoint: endpoint)
                    ConfigurationManager.shared.saveConfiguration(for: .custom, config: config)
                    saved = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { saved = false }
                }
                .disabled(apiKey.isEmpty || endpoint.isEmpty)
                
                if saved {
                    Text("Saved!").foregroundColor(.green).font(.caption)
                }
                
                Spacer()
            }
            
            Text("Supports OpenAI-compatible APIs (Ollama, LM Studio, etc.)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding(20)
    }
}