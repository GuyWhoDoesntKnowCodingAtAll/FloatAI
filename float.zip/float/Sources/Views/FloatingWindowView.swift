import SwiftUI
import AppKit

private let kCollapsedSize = NSSize(width: 44, height: 44)
private let kExpandedSize = NSSize(width: 360, height: 520)

class FloatingWindowController: NSWindowController, ObservableObject {
    @Published var isExpanded = false
    
    static var shared: FloatingWindowController?
    
    convenience init() {
        let window = NSWindow(
            contentRect: NSRect(origin: .zero, size: kExpandedSize),
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        
        window.isOpaque = false
        window.backgroundColor = .clear
        window.level = .floating
        window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary]
        window.isMovableByWindowBackground = true
        window.hasShadow = true
        window.isReleasedWhenClosed = false
        
        window.center()
        
        self.init(window: window)
        
        FloatingWindowController.shared = self
        
        updateContentView()
        
        window.setFrame(NSRect(origin: window.frame.origin, size: kCollapsedSize), display: false)
        isExpanded = false
    }
    
    private func updateContentView() {
        let contentView = FloatingContentView(
            isExpanded: Binding(
                get: { self.isExpanded },
                set: { self.setExpanded($0, animated: true) }
            )
        )
        window?.contentView = NSHostingView(rootView: contentView)
    }
    
    func setExpanded(_ expanded: Bool, animated: Bool) {
        guard let window = window else { return }
        
        let currentFrame = window.frame
        let currentMaxX = currentFrame.maxX
        let currentMaxY = currentFrame.maxY
        
        let newSize = expanded ? kExpandedSize : kCollapsedSize
        let newOrigin = NSPoint(
            x: currentMaxX - newSize.width,
            y: currentMaxY - newSize.height
        )
        
        isExpanded = expanded
        
        if expanded {
            window.level = .floating
        } else {
            window.level = .normal
        }
        
        if animated {
            NSAnimationContext.runAnimationGroup { context in
                context.duration = 0.25
                context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
                window.animator().setFrame(NSRect(origin: newOrigin, size: newSize), display: true)
            }
        } else {
            window.setFrame(NSRect(origin: newOrigin, size: newSize), display: true)
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.updateContentView()
            if expanded {
                NSApp.activate(ignoringOtherApps: true)
                self.window?.makeKeyAndOrderFront(nil)
            }
        }
    }
    
    func toggleExpanded() {
        setExpanded(!isExpanded, animated: true)
    }
    
    override func showWindow(_ sender: Any?) {
        window?.orderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }
}

struct FloatingContentView: View {
    @Binding var isExpanded: Bool
    @StateObject private var viewModel = ChatViewModel()
    
    var body: some View {
        ZStack {
            if isExpanded {
                RoundedRectangle(cornerRadius: 18)
                    .fill(Color.black.opacity(0.85))
                    .shadow(color: .black.opacity(0.3), radius: 15, x: 0, y: 8)
                
                ExpandedView(viewModel: viewModel, isExpanded: $isExpanded)
            } else {
                CollapsedIconView(isExpanded: $isExpanded)
            }
        }
        .frame(width: isExpanded ? 360 : 44, height: isExpanded ? 520 : 44)
        .animation(.spring(response: 0.3, dampingFraction: 0.75), value: isExpanded)
    }
}

struct CollapsedIconView: View {
    @Binding var isExpanded: Bool
    @State private var isHovering = false
    
    var body: some View {
        ZStack {
            Circle()
                .fill(LinearGradient(
                    colors: [Color.purple, Color.blue],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
                .frame(width: 44, height: 44)
                .shadow(color: .purple.opacity(0.4), radius: isHovering ? 12 : 8, x: 0, y: isHovering ? 6 : 4)
                .scaleEffect(isHovering ? 1.1 : 1.0)
            
            Image(systemName: "brain.head.profile")
                .font(.system(size: 22, weight: .medium))
                .foregroundColor(.white)
        }
        .frame(width: 60, height: 60)
        .contentShape(Rectangle())
        .onTapGesture {
            isExpanded = true
        }
        .onHover { hovering in
            isHovering = hovering
            NSCursor.pointingHand.push()
        }
        .contextMenu {
            Button("Quit FloatAI") {
                NSApplication.shared.terminate(nil)
            }
        }
    }
}

struct ExpandedView: View {
    @ObservedObject var viewModel: ChatViewModel
    @Binding var isExpanded: Bool
    @State private var isDragging = false
    
    var body: some View {
        VStack(spacing: 0) {
            HeaderView(isExpanded: $isExpanded, viewModel: viewModel)
            
            Divider()
            
            ChatMessagesView(viewModel: viewModel)
            
            Divider()
            
            ChatInputView(viewModel: viewModel)
        }
        .padding(0)
    }
}

struct HeaderView: View {
    @Binding var isExpanded: Bool
    @ObservedObject var viewModel: ChatViewModel
    
    private var availableModels: [String] {
        switch viewModel.selectedProvider {
        case .openai:
            return ["gpt-4o", "gpt-4-turbo", "gpt-4", "gpt-3.5-turbo"]
        case .anthropic:
            return ["claude-3-5-sonnet-20241022", "claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-3-haiku-20240307"]
        case .custom:
            let config = ConfigurationManager.shared.getConfiguration(for: .custom)
            return config.model.isEmpty ? ["llama3"] : [config.model]
        }
    }
    
    var body: some View {
        HStack(spacing: 8) {
            Button(action: {
                isExpanded = false
            }) {
                Image(systemName: "chevron.down")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
            
            Text("FloatAI")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.primary)
            
            Spacer()
            
            Menu {
                ForEach(AIProvider.allCases) { provider in
                    let config = ConfigurationManager.shared.getConfiguration(for: provider)
                    let hasKey = !config.apiKey.isEmpty
                    Button(action: {
                        viewModel.selectProvider(provider)
                    }) {
                        HStack {
                            Text(provider.rawValue)
                            if viewModel.selectedProvider == provider {
                                Image(systemName: "checkmark")
                            }
                        }
                    }
                    .disabled(!hasKey)
                }
            } label: {
                HStack(spacing: 4) {
                    Text(viewModel.selectedProvider.rawValue)
                        .font(.system(size: 12, weight: .medium))
                    Image(systemName: "chevron.down")
                        .font(.system(size: 10))
                }
                .foregroundColor(.secondary)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color(nsColor: .controlBackgroundColor))
                .cornerRadius(6)
            }
            .menuStyle(.borderlessButton)
            .fixedSize()
            
            Menu {
                ForEach(availableModels, id: \.self) { model in
                    Button(action: {
                        viewModel.selectedModel = model
                    }) {
                        HStack {
                            Text(model)
                            if viewModel.selectedModel == model {
                                Image(systemName: "checkmark")
                            }
                        }
                    }
                }
            } label: {
                HStack(spacing: 4) {
                    Text(viewModel.selectedModel.isEmpty ? "Select Model" : viewModel.selectedModel)
                        .font(.system(size: 11, weight: .medium))
                        .lineLimit(1)
                    Image(systemName: "chevron.down")
                        .font(.system(size: 10))
                }
                .foregroundColor(.secondary)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Color(nsColor: .controlBackgroundColor))
                .cornerRadius(6)
            }
            .menuStyle(.borderlessButton)
            .frame(maxWidth: 120)
            
            Button(action: {
                AppDelegate.shared?.openSettingsWindow()
            }) {
                Image(systemName: "gearshape")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
            
            Button(action: {
                NSApplication.shared.terminate(nil)
            }) {
                Image(systemName: "xmark.circle")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial)
    }
}

struct ChatMessagesView: View {
    @ObservedObject var viewModel: ChatViewModel
    
    var body: some View {
        VStack(spacing: 0) {
            if let error = viewModel.errorMessage {
                HStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.orange)
                    Text(error)
                        .font(.system(size: 12))
                        .foregroundColor(.secondary)
                    Spacer()
                    Button(action: { viewModel.errorMessage = nil }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 10))
                            .foregroundColor(.secondary)
                    }
                    .buttonStyle(.plain)
                }
                .padding(8)
                .background(Color.orange.opacity(0.1))
            }
            
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(viewModel.messages) { message in
                            MessageBubbleView(message: message)
                                .id(message.id)
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                }
                .onChange(of: viewModel.messages.count) { _ in
                    if let lastMessage = viewModel.messages.last {
                        DispatchQueue.main.async {
                            withAnimation {
                                proxy.scrollTo(lastMessage.id, anchor: .bottom)
                            }
                        }
                    }
                }
            }
        }
    }
}

struct MessageBubbleView: View {
    let message: ChatMessage
    @State private var showingCopy = false
    
    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            if message.role == .assistant {
                Image(systemName: "brain.head.profile")
                    .font(.system(size: 12))
                    .foregroundColor(.purple)
                    .frame(width: 20, height: 20)
            }
            
            VStack(alignment: message.role == .user ? .trailing : .leading, spacing: 4) {
                Text(message.content)
                    .font(.system(size: 13))
                    .foregroundColor(message.role == .user ? .white : .primary)
                    .textSelection(.enabled)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(
                        message.role == .user 
                            ? Color.purple 
                            : Color(nsColor: .controlBackgroundColor)
                    )
                    .cornerRadius(12)
                
                if message.role == .assistant {
                    HStack(spacing: 8) {
                        Button(action: {
                            NSPasteboard.general.clearContents()
                            NSPasteboard.general.setString(message.content, forType: .string)
                            showingCopy = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                showingCopy = false
                            }
                        }) {
                            Image(systemName: showingCopy ? "checkmark" : "doc.on.doc")
                                .font(.system(size: 10))
                                .foregroundColor(.secondary)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            
            if message.role == .user {
                Image(systemName: "person.circle.fill")
                    .font(.system(size: 12))
                    .foregroundColor(.blue)
                    .frame(width: 20, height: 20)
            }
        }
    }
}

struct ChatInputView: View {
    @ObservedObject var viewModel: ChatViewModel
    @State private var inputText = ""
    @State private var textFieldRef: NSTextField?
    
    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            NSViewRepresentableTextField(text: $inputText, onSubmit: sendMessage)
                .frame(height: 36)
            
            Button(action: sendMessage) {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 22))
                    .foregroundColor(inputText.isEmpty ? .gray : .purple)
            }
            .buttonStyle(.plain)
            .disabled(inputText.isEmpty)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                NSApp.activate(ignoringOtherApps: true)
            }
        }
    }
    
    private func sendMessage() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        viewModel.sendMessage(trimmed)
        inputText = ""
    }
}

struct NSViewRepresentableTextField: NSViewRepresentable {
    @Binding var text: String
    var onSubmit: () -> Void
    
    func makeNSView(context: Context) -> NSTextField {
        let textField = NSTextField()
        textField.placeholderString = "Type a message..."
        textField.font = NSFont.systemFont(ofSize: 13)
        textField.isBordered = false
        textField.drawsBackground = false
        textField.focusRingType = .none
        textField.bezelStyle = .roundedBezel
        textField.target = context.coordinator
        textField.action = #selector(Coordinator.textDidChange(_:))
        textField.delegate = context.coordinator
        return textField
    }
    
    func updateNSView(_ nsView: NSTextField, context: Context) {
        nsView.stringValue = text
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, NSTextFieldDelegate {
        var parent: NSViewRepresentableTextField
        
        init(_ parent: NSViewRepresentableTextField) {
            self.parent = parent
        }
        
        @objc func textDidChange(_ sender: NSTextField) {
            parent.text = sender.stringValue
        }
    }
}