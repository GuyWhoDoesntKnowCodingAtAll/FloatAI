import Foundation

enum ChatRole: String, Codable {
    case user
    case assistant
    case system
}

struct ChatMessage: Identifiable, Codable {
    let id: UUID
    let role: ChatRole
    let content: String
    let timestamp: Date
    
    init(id: UUID = UUID(), role: ChatRole, content: String, timestamp: Date = Date()) {
        self.id = id
        self.role = role
        self.content = content
        self.timestamp = timestamp
    }
}

enum AIProvider: String, CaseIterable, Codable, Identifiable {
    case openai = "OpenAI"
    case anthropic = "Anthropic"
    case custom = "Custom"
    
    var id: String { rawValue }
    
    var defaultModel: String {
        switch self {
        case .openai: return "gpt-4o"
        case .anthropic: return "claude-3-5-sonnet-20241022"
        case .custom: return ""
        }
    }
    
    var endpoint: String {
        switch self {
        case .openai: return "https://api.openai.com/v1/chat/completions"
        case .anthropic: return "https://api.anthropic.com/v1/messages"
        case .custom: return ""
        }
    }
    
    var headerKey: String {
        switch self {
        case .openai: return "Authorization"
        case .anthropic: return "x-api-key"
        case .custom: return "Authorization"
        }
    }
    
    var headerPrefix: String {
        switch self {
        case .openai: return "Bearer "
        case .anthropic: return ""
        case .custom: return ""
        }
    }
}

struct AIConfiguration: Codable {
    var provider: AIProvider
    var apiKey: String
    var model: String
    var customEndpoint: String
    
    init(provider: AIProvider = .openai, apiKey: String = "", model: String = "", customEndpoint: String = "") {
        self.provider = provider
        self.apiKey = apiKey
        self.model = model.isEmpty ? provider.defaultModel : model
        self.customEndpoint = customEndpoint
    }
}

class ConfigurationManager: ObservableObject {
    static let shared = ConfigurationManager()
    
    @Published var configurations: [AIProvider: AIConfiguration] = [:]
    
    private let userDefaults = UserDefaults.standard
    private let configKey = "AIConfigurations"
    
    private init() {
        loadConfigurations()
    }
    
    func loadConfigurations() {
        if let data = userDefaults.data(forKey: configKey),
           let decoded = try? JSONDecoder().decode([String: AIConfiguration].self, from: data) {
            configurations = decoded.reduce(into: [:]) { result, pair in
                if let provider = AIProvider(rawValue: pair.key) {
                    result[provider] = pair.value
                }
            }
        }
        
        for provider in AIProvider.allCases {
            if configurations[provider] == nil {
                configurations[provider] = AIConfiguration(provider: provider)
            }
        }
    }
    
    func saveConfiguration(for provider: AIProvider, config: AIConfiguration) {
        configurations[provider] = config
        saveToDisk()
    }
    
    func getConfiguration(for provider: AIProvider) -> AIConfiguration {
        return configurations[provider] ?? AIConfiguration(provider: provider)
    }
    
    private func saveToDisk() {
        let dict = configurations.reduce(into: [String: AIConfiguration]()) { result, pair in
            result[pair.key.rawValue] = pair.value
        }
        
        if let encoded = try? JSONEncoder().encode(dict) {
            userDefaults.set(encoded, forKey: configKey)
        }
    }
}