import Foundation
import Combine
import AppKit

class ChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var selectedProvider: AIProvider = .openai
    @Published var selectedModel: String = ""
    
    private let aiService = AIService.shared
    
    init() {
        loadSavedProvider()
    }
    
    func loadSavedProvider() {
        for provider in AIProvider.allCases {
            let config = ConfigurationManager.shared.getConfiguration(for: provider)
            if !config.apiKey.isEmpty {
                selectedProvider = provider
                selectedModel = config.model
                return
            }
        }
    }
    
    func selectProvider(_ provider: AIProvider) {
        let config = ConfigurationManager.shared.getConfiguration(for: provider)
        guard !config.apiKey.isEmpty else {
            errorMessage = "Please configure \(provider.rawValue) API key in Settings first."
            return
        }
        selectedProvider = provider
        selectedModel = config.model
        errorMessage = nil
    }
    
    func sendMessage(_ content: String) {
        let userMessage = ChatMessage(role: .user, content: content)
        messages.append(userMessage)
        
        isLoading = true
        errorMessage = nil
        
        Task { @MainActor in
            do {
                var config = ConfigurationManager.shared.getConfiguration(for: selectedProvider)
                
                guard !config.apiKey.isEmpty else {
                    errorMessage = "Please configure an API key in Settings."
                    isLoading = false
                    return
                }
                
                if !selectedModel.isEmpty {
                    config.model = selectedModel
                }
                
                let response = try await aiService.sendMessage(messages, config: config)
                
                let assistantMessage = ChatMessage(role: .assistant, content: response)
                messages.append(assistantMessage)
            } catch {
                errorMessage = error.localizedDescription
                
                let errorMsg = ChatMessage(
                    role: .assistant,
                    content: "Error: \(error.localizedDescription)"
                )
                messages.append(errorMsg)
            }
            
            isLoading = false
        }
    }
    
    func clearHistory() {
        messages.removeAll()
    }
    
    func copyMessage(_ content: String) {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(content, forType: .string)
    }
}